CREATE DATABASE  IF NOT EXISTS `minimarket4` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `minimarket4`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: minimarket4
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_detventa`
--

DROP TABLE IF EXISTS `t_detventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_detventa` (
  `detven_id` int NOT NULL AUTO_INCREMENT,
  `detven_cant` int NOT NULL,
  `detven_subtotal` decimal(5,2) NOT NULL,
  `cabven_id` int NOT NULL,
  `prod_id` int NOT NULL,
  PRIMARY KEY (`detven_id`),
  KEY `t_detventa_cabven_id_7ecdfcf4_fk_t_cabventa_cabven_id` (`cabven_id`),
  KEY `t_detventa_prod_id_6bcd731a_fk_t_producto_prod_id` (`prod_id`),
  CONSTRAINT `t_detventa_cabven_id_7ecdfcf4_fk_t_cabventa_cabven_id` FOREIGN KEY (`cabven_id`) REFERENCES `t_cabventa` (`cabven_id`),
  CONSTRAINT `t_detventa_prod_id_6bcd731a_fk_t_producto_prod_id` FOREIGN KEY (`prod_id`) REFERENCES `t_producto` (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_detventa`
--

LOCK TABLES `t_detventa` WRITE;
/*!40000 ALTER TABLE `t_detventa` DISABLE KEYS */;
INSERT INTO `t_detventa` VALUES (1,10,145.00,6,2),(2,10,145.00,7,2),(3,5,7.50,7,3),(4,10,145.00,8,2),(5,5,7.50,8,3),(6,10,145.00,9,2),(7,10,145.00,10,2),(8,10,145.00,11,2),(9,5,7.50,11,3),(10,10,145.00,12,2),(11,5,7.50,12,3),(12,10,145.00,13,2),(13,5,7.50,13,3),(14,10,145.00,14,2),(15,5,7.50,14,3),(16,10,145.00,15,2),(17,5,7.50,15,3),(18,10,145.00,16,2),(19,5,7.50,16,3),(20,10,145.00,17,2),(21,10,145.00,18,2),(22,10,145.00,19,2),(23,10,145.00,20,2),(24,10,145.00,21,2),(25,5,7.50,21,3);
/*!40000 ALTER TABLE `t_detventa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-17 19:38:12
